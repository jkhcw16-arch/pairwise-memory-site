# Patent Notice

## Pairwise Memory Architecture

The Pairwise Memory Architecture, including aspects of its memory organization,
prime-lattice structures, recursive memory composition, temporal reasoning,
deterministic retrieval, encoding methods, traversal methods, and related
implementations, may be the subject of pending or future patent applications
and other intellectual-property rights owned or controlled by Jamie Kinney.

Copyright (c) 2026 Jamie Kinney. All Rights Reserved.

## No Patent License

Access to this repository, its source code, documentation, tests, examples, or
other materials does not grant, by implication, estoppel, or otherwise, any
license or other right under any patent or patent application.

Any patent rights are separate from copyright permissions and from any written
software license that may apply to particular materials in this repository.
No right to make, use, sell, offer for sale, import, sublicense, commercialize,
or otherwise practice any patented or patent-pending invention is granted
except under a separate written agreement expressly providing such rights.

## Patent Status

This repository does not identify any particular invention as patented or
patent pending unless the repository owner separately publishes accurate and
current patent-status information for that invention.

Do not interpret publication of this repository, use of the term "patent" in
project documentation, or discussion of patent strategy as a representation
that a patent application has been filed, remains pending, has issued, or
covers any particular implementation.

## Contributions

Submission or acceptance of a contribution does not, by itself, create a
patent license beyond rights expressly granted in a separate written agreement.
Contributors are responsible for ensuring that they have authority to submit
their contributions.

## Licensing Inquiries

For patent, OEM, commercial, evaluation, or other licensing inquiries, contact
the repository owner through an authorized contact method published by the
repository owner.

## Legal Review

This notice is intended as a repository-level intellectual-property notice and
should be reviewed by qualified intellectual-property counsel before public
release or before it is relied upon for a specific patent or licensing strategy.
