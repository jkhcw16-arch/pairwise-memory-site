# Pairwise Memory Architecture Versioning Policy

## Purpose

Pairwise Memory Architecture uses Semantic Versioning 2.0.0 as the basis for release numbering, expressed as:

```text
MAJOR.MINOR.PATCH
```

For this repository, version changes communicate compatibility of the declared public software interface and documented behavior. They do not represent patent status, patent scope, research validation, performance guarantees, or commercial-license terms.

## Current development phase

Until the project declares a stable 1.0.0 public API, releases use the `0.y.z` series.

During this phase, the architecture and API may evolve significantly. Every release must still identify breaking changes explicitly in its release notes.

Examples:

```text
0.1.0
0.1.1
0.2.0
0.3.0-rc.1
```

## Version components

### PATCH

Increment PATCH for backward-compatible corrections that do not intentionally change the public interface.

Examples include:

- Correcting a defect in an existing operation
- Fixing erroneous cycle detection while preserving the documented API
- Correcting duplicate-edge validation
- Documentation corrections that ship as part of a release

Example:

```text
0.2.3 -> 0.2.4
```

### MINOR

Increment MINOR for backward-compatible functionality or, while the project remains below 1.0.0, for a development release that intentionally changes an unstable interface.

Examples include:

- Adding a new retrieval capability
- Adding a new topology factory
- Adding temporal-memory functionality
- Introducing a new optional API
- Changing an unstable pre-1.0 API in a way documented as breaking

Example:

```text
0.2.4 -> 0.3.0
```

For pre-1.0 breaking changes, release notes must contain a clearly labeled `Breaking changes` section.

### MAJOR

After 1.0.0, increment MAJOR for incompatible changes to the declared stable public API or compatibility contract.

Examples may include:

- Removing a stable public API
- Changing stable call semantics incompatibly
- Changing a stable persisted representation incompatibly
- Changing documented reconstruction behavior in a way that requires consumers to migrate

Example:

```text
1.7.2 -> 2.0.0
```

## Pre-release versions

Use pre-release identifiers when publishing builds that are not intended to represent the final release.

Recommended identifiers:

```text
0.3.0-alpha.1
0.3.0-beta.1
0.3.0-rc.1
```

Repository convention:

- `alpha`: early integration or experimental release
- `beta`: feature-complete candidate undergoing broader validation
- `rc`: release candidate intended to approximate the final release

Promoting a release candidate removes the pre-release suffix:

```text
0.3.0-rc.2 -> 0.3.0
```

## Build metadata

Build metadata may be used when an artifact needs additional traceability without changing version precedence.

Example:

```text
0.3.0+sha.abc1234
```

Release tags should normally omit build metadata unless there is a specific artifact-management need.

## Public API definition

The versioning contract applies to interfaces intentionally declared public by the repository's code or documentation.

Internal implementation details, private helpers, tests, experimental modules, and explicitly unstable interfaces are not automatically part of the stable compatibility contract.

Before 1.0.0, documentation should clearly identify interfaces intended to become stable.

## Architecture and data compatibility

Release review must separately consider compatibility in these areas:

1. Python/API compatibility
2. Encoded-memory interpretation
3. Composite-memory metadata
4. Temporal representation
5. Graph/hierarchy semantics
6. Serialized or persisted data, when applicable

A change can require a higher version even if Python function signatures remain unchanged when the documented compatibility contract changes materially.

## Research and mathematical changes

Changes to mathematical notation, proofs, experimental hypotheses, benchmarks, or research interpretation do not automatically determine a version increment.

If such a change alters executable or documented public behavior, version it according to the compatibility impact above.

Do not use version numbers to imply that a mathematical claim is proven, that performance has been independently validated, or that a patent has been filed or granted.

## Security releases

Security fixes follow the same compatibility rules as other releases.

When a security correction is backward-compatible, PATCH is normally appropriate. If remediation requires an incompatible stable API change after 1.0.0, increment MAJOR.

Security disclosures should follow `SECURITY.md` and should not expose unnecessary vulnerability details before coordinated remediation.

## Version source of truth

The release version in `pyproject.toml` is the package version source of truth for a release.

For every release:

```toml
[project]
version = "0.3.0"
```

must agree with the Git tag and release title.

## Git tags

Use annotated release tags prefixed with `v`:

```text
v0.1.0
v0.2.0
v0.3.0-rc.1
v1.0.0
```

Once a released version is published, do not silently replace its contents. Corrections should receive a new version.

## Release branches

The repository may develop on `main` and use short-lived branches for release preparation when needed.

Versioning does not require a permanent release branch. The released tag must identify the exact reviewed release commit.

## Release notes

Each release should document, when applicable:

```text
New features
Bug fixes
Recursive/topology changes
API changes
Breaking changes
Security changes
Documentation changes
Known limitations
Migration guidance
```

Breaking changes must be explicit rather than inferred from the version number alone.

## 1.0.0 stability threshold

Version `1.0.0` should be reserved for the point at which the project intentionally declares a stable public compatibility contract.

Before declaring 1.0.0, review at minimum:

- Public API boundaries
- Prime-allocation behavior
- Encoding and reconstruction semantics
- Recursive composition semantics
- Temporal representation
- Graph/hierarchy behavior
- Persistence formats, if any
- Error and exception behavior
- Supported Python versions
- Documentation and migration expectations

## Intellectual-property independence

Software version numbers are independent of copyright, patent, trade-secret, and commercial-license status.

A change in patent status does not by itself require a software version increment. Likewise, a software release number must not be interpreted as granting intellectual-property rights.

Refer to `LICENSE` and `PATENTS.md` for applicable notices.

## Release checklist

Every release should be reviewed against `docs/RELEASE_CHECKLIST.md` before tagging and publication.
