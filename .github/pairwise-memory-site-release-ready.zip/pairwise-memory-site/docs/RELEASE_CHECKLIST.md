# Pairwise Memory Architecture Release Checklist

Use this checklist before creating a release or publishing a release candidate for the Pairwise Memory Architecture repository.

## 1. Release definition

- [ ] Define the release version.
- [ ] Define the release scope.
- [ ] Identify user-visible changes.
- [ ] Identify breaking API, storage, mathematical, or behavioral changes.
- [ ] Confirm experimental features are clearly identified.
- [ ] Confirm deferred work is tracked separately.

## 2. Intellectual property review

- [ ] Confirm `LICENSE` contains the intended proprietary terms.
- [ ] Confirm `PATENTS.md` accurately reflects current patent-status language.
- [ ] Confirm the release does not make an unsupported `patented` or `patent pending` claim.
- [ ] Review public documentation for confidential, unpublished, or trade-secret material that should not be released.
- [ ] Confirm third-party code, data, dependencies, and examples have been reviewed for applicable license obligations.
- [ ] Confirm commercial and licensing contact information is current.
- [ ] Obtain qualified IP/legal review when appropriate before a public release.

## 3. Repository metadata

- [ ] Confirm `pyproject.toml` contains the intended version.
- [ ] Confirm the supported Python versions are accurate.
- [ ] Confirm package name and metadata are correct.
- [ ] Confirm the repository URL is `https://github.com/jkhcw16-arch/pairwise-memory-site`.
- [ ] Confirm no placeholder values such as `OWNER`, `REPOSITORY`, or `@OWNER` remain.
- [ ] Confirm `CODEOWNERS` contains valid GitHub owners or teams.

## 4. Core correctness

- [ ] Prime allocation uniqueness tests pass.
- [ ] Prime-to-symbol and symbol-to-prime round-trip tests pass.
- [ ] Encoding and reconstruction tests pass.
- [ ] Temporal-memory tests pass when included in the release.
- [ ] Recursive composition tests pass.
- [ ] Recursive expansion terminates safely.
- [ ] Cycle-detection tests pass.
- [ ] Duplicate-edge rejection tests pass.
- [ ] Duplicate self-loop rejection tests pass.
- [ ] Failed duplicate insertion leaves graph state unchanged.

## 5. Topology regression suite

- [ ] Self-cycle topology passes structural tests.
- [ ] Multiple-self-loop topology passes structural tests.
- [ ] Two-node cycle passes structural tests.
- [ ] Multi-node cycle passes structural tests.
- [ ] Diamond topology passes structural tests.
- [ ] Star topology passes structural tests.
- [ ] Deep-chain topology passes structural tests.
- [ ] Expected node counts are asserted.
- [ ] Expected edge counts are asserted.
- [ ] Existing edges reject reinsertion across parameterized topology tests.
- [ ] Non-cyclic topologies expand without false cycle detection.

## 6. Automated tests and quality

Run the release test suite from a clean environment:

```bash
python -m pip install --upgrade pip
pip install -e ".[dev]"
ruff check src tests
ruff format --check src tests
mypy src
pytest -v
```

Then confirm:

- [ ] Full test suite passes.
- [ ] No unexpected skipped or xfailed tests remain.
- [ ] Coverage output is reviewed.
- [ ] Lint checks pass.
- [ ] Format checks pass.
- [ ] Type checking is reviewed and accepted.
- [ ] Source files compile successfully.

## 7. CI validation

- [ ] GitHub Actions workflow syntax is valid.
- [ ] CI runs on every intended supported Python version.
- [ ] CI succeeds for the release commit.
- [ ] Topology and duplicate-edge tests execute in CI.
- [ ] Coverage artifact generation succeeds if enabled.
- [ ] Workflow permissions remain least-privilege for the required jobs.
- [ ] README workflow badge resolves to the intended workflow.

## 8. Security review

- [ ] `SECURITY.md` is present and current.
- [ ] Security contact is `Jkhcw9277@icloud.com`.
- [ ] No passwords, API keys, tokens, private keys, credentials, or secrets are committed.
- [ ] No unintended personal or confidential data is committed.
- [ ] Dependency changes are reviewed.
- [ ] Untrusted input paths are reviewed where applicable.
- [ ] Recursive and pathological graph inputs are reviewed for resource-exhaustion risk.
- [ ] Serialization or deserialization behavior is reviewed where applicable.
- [ ] CI configuration is reviewed for secret exposure or excessive permissions.

## 9. Documentation

- [ ] `README.md` matches the actual implementation.
- [ ] Installation commands work from a clean checkout.
- [ ] Quick-start examples use current APIs.
- [ ] Architecture descriptions do not overstate demonstrated behavior.
- [ ] Mathematical notation matches the implementation model.
- [ ] Testing instructions are current.
- [ ] Commercial licensing section is current.
- [ ] License section is current.
- [ ] Patent notice is current.
- [ ] `CONTRIBUTING.md` matches the actual development workflow.
- [ ] Community health documentation is current.

## 10. Community files

- [ ] `CODE_OF_CONDUCT.md` is present.
- [ ] `CONTRIBUTING.md` is present.
- [ ] `SECURITY.md` is present.
- [ ] `.github/CODEOWNERS` is present.
- [ ] `.github/PULL_REQUEST_TEMPLATE.md` is present.
- [ ] Bug report issue form is present.
- [ ] Feature request issue form is present.
- [ ] Documentation issue form is present.
- [ ] Research proposal issue form is present.
- [ ] Issue-template configuration routes security matters privately.

## 11. Clean-release verification

- [ ] Clone or extract the exact release candidate into a clean directory.
- [ ] Confirm generated files such as `__pycache__`, `.pyc`, coverage output, build output, and local virtual environments are excluded.
- [ ] Install the package using documented commands.
- [ ] Import the package successfully.
- [ ] Run the full test suite from the clean copy.
- [ ] Verify repository links in documentation.
- [ ] Verify the release archive opens without errors.

## 12. Release notes

Release notes should clearly separate:

- New features
- Correctness fixes
- Recursive/topology changes
- API changes
- Breaking changes
- Security changes, when safe to disclose
- Documentation changes
- Known limitations

Confirm:

- [ ] Release notes describe only behavior actually included in the release.
- [ ] Experimental claims are labeled appropriately.
- [ ] No confidential patent or commercialization information is unintentionally disclosed.
- [ ] Upgrade or migration guidance is provided if required.

## 13. Tag and release

Immediately before releasing:

- [ ] Confirm the intended release commit is checked out.
- [ ] Confirm the working tree is clean.
- [ ] Confirm the version matches the intended release tag.
- [ ] Confirm CI is green for the release commit.
- [ ] Create the release tag using the repository's chosen versioning convention.
- [ ] Create the GitHub release from that exact tag.
- [ ] Attach only intended release artifacts.
- [ ] Review the published release page after publication.

## 14. Post-release verification

- [ ] Confirm the release tag resolves to the intended commit.
- [ ] Confirm downloadable artifacts are the intended files.
- [ ] Confirm README badges and links still resolve.
- [ ] Confirm installation from the released source works where applicable.
- [ ] Monitor new bug and security reports.
- [ ] Record follow-up work for the next release.

## Release approval record

```text
Release version:
Release commit:
Release tag:
Release candidate tested by:
IP/legal review, if applicable:
Security review:
Release approved by:
Release date:
Notes:
```
