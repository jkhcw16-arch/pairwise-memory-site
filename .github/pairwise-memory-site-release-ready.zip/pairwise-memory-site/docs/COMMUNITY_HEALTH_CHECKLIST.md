# Community Health Checklist

Use this checklist before making the Pairwise Memory Architecture repository public and during periodic repository reviews.

## Core repository documentation

- [ ] `README.md` explains the project purpose and architecture.
- [ ] `README.md` includes installation instructions.
- [ ] `README.md` includes a minimal usage example.
- [ ] `README.md` includes the CI workflow status badge.
- [ ] `LICENSE` contains the intended project license.
- [ ] `CONTRIBUTING.md` explains contribution and test requirements.
- [ ] `CODE_OF_CONDUCT.md` defines community participation standards.
- [ ] `SECURITY.md` explains private vulnerability reporting.

## GitHub community configuration

- [ ] `.github/CODEOWNERS` contains valid GitHub users or teams instead of placeholders.
- [ ] `.github/PULL_REQUEST_TEMPLATE.md` is present.
- [ ] `.github/ISSUE_TEMPLATE/bug_report.yml` is present and valid.
- [ ] Issue forms include `name` and `description` metadata.
- [ ] Repository contact information used by security or conduct policies is current.

## Continuous integration

- [ ] `.github/workflows/ci.yml` exists.
- [ ] Unit tests run on pull requests.
- [ ] Recursive topology tests run in CI.
- [ ] Duplicate-edge regression tests run in CI.
- [ ] Node-count and edge-count tests run in CI.
- [ ] Cycle-detection tests run in CI.
- [ ] Coverage output is generated.
- [ ] Lint and format checks run in CI or an equivalent quality workflow.

## Pairwise Memory correctness

- [ ] Prime allocation is one-to-one for registered symbols.
- [ ] Recursive composition has round-trip tests.
- [ ] Duplicate graph edges are rejected.
- [ ] Duplicate self-loop edges are rejected.
- [ ] Self-loop cycles are tested.
- [ ] Multiple independent self-loops are tested.
- [ ] Two-node cycles are tested.
- [ ] Multi-node cycles are tested.
- [ ] Diamond and star topologies are tested.
- [ ] Deep-chain recursion behavior is tested.
- [ ] Factory topology node counts are asserted.
- [ ] Factory topology edge counts are asserted.
- [ ] Failed duplicate insertion does not mutate graph counts.

## Contributor readiness

- [ ] Development dependencies can be installed from documented commands.
- [ ] A clean checkout can run `pytest` successfully.
- [ ] Formatting and lint commands in `CONTRIBUTING.md` are accurate.
- [ ] New topology requirements are documented.
- [ ] Commit-message guidance is documented.
- [ ] Pull requests ask contributors to disclose breaking changes.

## Security and integrity

- [ ] No credentials, tokens, personal data, or private keys are committed.
- [ ] Security reports have a private reporting path.
- [ ] Dependency and CI configuration are reviewed for unnecessary privileges.
- [ ] Recursive traversal has explicit protections against runaway behavior.
- [ ] Resource-exhaustion risks from pathological topology inputs are tested or documented.
- [ ] Research, benchmark, and mathematical claims distinguish demonstrated results from hypotheses.

## Release readiness

- [ ] Public API behavior is documented.
- [ ] Version metadata is consistent.
- [ ] Changelog or release notes are prepared when appropriate.
- [ ] Required tests pass on supported Python versions.
- [ ] Repository links and badges resolve correctly.
- [ ] Placeholders such as `<OWNER>`, `<REPOSITORY>`, and `@OWNER` have been replaced.

## GitHub Community Profile review

GitHub's Community Profile checklist checks for recommended community health files such as README, CODE_OF_CONDUCT, LICENSE, and CONTRIBUTING. GitHub also recognizes an issue form for the checklist when it is in `.github/ISSUE_TEMPLATE` and contains valid `name` and `description` fields.

After publishing the repository, review its Community Profile and resolve any missing recommended items.
