# Architecture
Pairwise relationship-centric memory system.
