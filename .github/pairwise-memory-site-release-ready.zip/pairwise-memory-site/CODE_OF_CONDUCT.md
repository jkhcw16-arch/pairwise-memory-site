# Code of Conduct

## Our Commitment

We are committed to maintaining a respectful, professional, and constructive environment for everyone who participates in the Pairwise Memory Architecture project.

Contributors, maintainers, reviewers, researchers, and community members are expected to engage in good faith and to focus technical discussion on correctness, reproducibility, implementation quality, and the advancement of the project.

## Expected Behavior

Examples of behavior that supports a positive community include:

- Treating other participants with respect and professionalism.
- Giving and receiving technical feedback constructively.
- Challenging ideas, implementations, proofs, and benchmarks without attacking people.
- Clearly distinguishing verified results from hypotheses, proposals, and experimental findings.
- Respecting intellectual property, licensing requirements, and attribution obligations.
- Protecting private information, credentials, security-sensitive details, and unpublished material.
- Helping make technical discussions accessible to contributors with different backgrounds and levels of experience.
- Accepting reasonable maintainer decisions concerning project scope, architecture, testing, and repository standards.

## Unacceptable Behavior

Unacceptable behavior includes:

- Harassment, threats, intimidation, or personal attacks.
- Discriminatory, hateful, or demeaning language or conduct.
- Deliberate disruption of technical discussions, reviews, issues, or pull requests.
- Publishing another person's private information without permission.
- Knowingly submitting malicious code, compromised dependencies, credentials, or deceptive test results.
- Misrepresenting authorship, experimental results, benchmarks, or mathematical claims.
- Repeatedly ignoring repository contribution, security, or review requirements after maintainers have provided guidance.
- Retaliation against someone who raises a good-faith technical, security, conduct, or research-integrity concern.

## Technical and Research Integrity

Because this project includes experimental memory architectures and mathematical mechanisms, contributors should strive to make claims that are reproducible and appropriately qualified.

When proposing architectural, mathematical, or performance claims, contributors should provide supporting tests, proofs, references, benchmarks, or clearly identified assumptions when appropriate.

Security vulnerabilities should not be disclosed through public issues when doing so would unnecessarily expose users to risk. Follow the repository's `SECURITY.md` policy for security reports.

## Scope

This Code of Conduct applies to project spaces, including repository issues, pull requests, discussions, reviews, documentation, and other official project communication channels.

It also applies when an individual is officially representing the project in another public space.

## Reporting Conduct Issues

If you experience or observe unacceptable behavior, report it privately to the project maintainers through an appropriate private contact method published by the repository owner.

Do not include sensitive personal information in a public issue.

Reports should include enough context for maintainers to understand and review the concern. Maintainers should handle reports as confidentially as reasonably possible.

## Enforcement

Project maintainers are responsible for interpreting and enforcing this Code of Conduct. Depending on the circumstances, maintainers may:

1. Request a correction or clarification.
2. Issue a private or public warning.
3. Remove or edit inappropriate project content where repository permissions allow.
4. Restrict participation in project spaces.
5. Remove a contributor from project-managed spaces for serious or repeated violations.

Enforcement decisions should consider context, severity, repetition, impact, and whether corrective action was taken.

## Good-Faith Disagreement

Technical disagreement is expected and encouraged when conducted respectfully. Disagreement about algorithms, architecture, mathematics, tests, performance, or project direction is not itself a conduct violation.

The standard is how participants engage with one another while resolving those disagreements.

## Questions

Questions about this Code of Conduct may be directed privately to the project maintainers.
