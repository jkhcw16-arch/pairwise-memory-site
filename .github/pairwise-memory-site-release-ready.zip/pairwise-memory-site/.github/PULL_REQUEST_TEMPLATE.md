## Summary

Describe what this pull request changes and why.

## Type of change

- [ ] Feature
- [ ] Bug fix
- [ ] Refactor
- [ ] Tests
- [ ] Documentation
- [ ] Performance
- [ ] Other

## Pairwise Memory invariants

If applicable, confirm that this change preserves:

- [ ] Deterministic behavior
- [ ] Prime allocation uniqueness
- [ ] Lossless reconstruction
- [ ] Recursive composability
- [ ] Duplicate-edge rejection
- [ ] Cycle detection behavior
- [ ] Node and edge count integrity

## Testing

Describe the tests added or updated.

- [ ] Unit tests added or updated
- [ ] Edge-case or regression tests added or updated
- [ ] Recursive topology tests added or updated when applicable
- [ ] `pytest` passes locally
- [ ] `ruff check src tests` passes locally
- [ ] `ruff format --check src tests` passes locally

## Documentation

- [ ] README or documentation updated if behavior changed
- [ ] No documentation change required

## Breaking changes

Describe any API, storage, mathematical, or behavioral compatibility changes. Write `None` if there are none.

## Notes for reviewers

Call out mathematical assumptions, prime-lattice invariants, recursion concerns, performance implications, or follow-up work.
