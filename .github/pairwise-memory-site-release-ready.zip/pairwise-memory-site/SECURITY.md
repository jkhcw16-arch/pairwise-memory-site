# Security Policy

## Reporting a Vulnerability

Please do **not** report suspected security vulnerabilities through public GitHub issues, discussions, pull requests, or other public channels.

Report security concerns privately to:

**Jamie Kinney**  
**Email:** Jkhcw9277@icloud.com

Use a clear subject such as:

```text
SECURITY: Pairwise Memory vulnerability report
```

## What to Include

When possible, include enough information to reproduce and evaluate the issue safely:

- A concise description of the vulnerability
- The affected file, module, component, branch, tag, or commit
- Relevant configuration or environment details
- Minimal reproduction steps
- Observed behavior and expected behavior
- Potential impact
- Relevant logs or traceback with credentials and private data removed
- Whether you believe the issue is already publicly known

Do not include third-party credentials, private keys, access tokens, personal data, confidential customer information, or other secrets in a report.

## Pairwise Memory Security Scope

Security-relevant reports may include issues affecting:

- Prime-lattice encoding or decoding integrity
- Memory reconstruction integrity
- Recursive traversal termination
- Cycle-detection bypasses
- Pathological graph inputs that cause unintended resource exhaustion
- Untrusted serialization or deserialization behavior
- Input validation
- Dependency vulnerabilities
- CI/CD or repository automation
- Credential or secret exposure
- Unauthorized access to protected or proprietary material

Ordinary correctness bugs that do not create a security concern should use the repository's bug-report issue form instead.

## Supported Versions

Pairwise Memory Architecture is under active development. No public version is currently designated as a long-term security-supported release unless explicitly identified by the repository owner.

Security fixes may therefore be applied to the actively maintained development version rather than backported to historical revisions.

## Coordinated Disclosure

Please allow the maintainer an opportunity to investigate a reported vulnerability before publishing technical details that could expose users or systems to unnecessary risk.

The maintainer may request additional information needed to reproduce, assess, or remediate the issue.

Do not intentionally access data that you do not own or have authorization to access, disrupt third-party services, or use a suspected vulnerability to cause harm.

## No Authorization Beyond Applicable Rights

This security policy provides a reporting channel. It does not grant permission to access systems, accounts, data, infrastructure, source material, or intellectual property beyond rights you otherwise possess.

It does not grant a patent, copyright, commercial, evaluation, or other intellectual-property license.

See [`LICENSE`](LICENSE) and [`PATENTS.md`](PATENTS.md) for the repository's applicable intellectual-property notices.

## Security and Licensing Contact

**Jamie Kinney**  
**Jkhcw9277@icloud.com**
