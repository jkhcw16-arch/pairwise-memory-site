# Pairwise Memory Architecture

> Proprietary deterministic memory architecture exploring prime-lattice encoding, temporal indexing, recursive memory composition, graph traversal, and exact symbolic recall.

[![Pairwise Memory CI](https://github.com/jkhcw16-arch/pairwise-memory-site/actions/workflows/ci.yml/badge.svg)](https://github.com/jkhcw16-arch/pairwise-memory-site/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/python-3.11%2B-blue.svg)
![License](https://img.shields.io/badge/license-Proprietary-red.svg)

## Overview

Pairwise Memory Architecture is an experimental software architecture for representing memory through deterministic relationships rather than relying exclusively on probabilistic similarity search.

The current reference implementation centers on a **Prime Lattice**. Symbols receive unique prime identifiers, memories are composed from those identifiers, and recursive composite memories can become components of higher-order memories.

The repository is intended to support development and evaluation of concepts including:

- Pairwise memory representation
- Prime-indexed symbolic addressing
- Deterministic encoding and recall
- Temporal prime indexing
- Recursive memory composition
- Hierarchical memory relationships
- Cycle-safe recursive traversal
- Topology and graph-integrity testing

This project is under active development. Architectural and mathematical descriptions should be treated as implementation and research material unless expressly identified as a proven result.

## Conceptual Model

Given primes assigned to symbols:

```text
DOG  = 2
PARK = 3
DAY  = 5
```

a simple encoded memory can be represented as:

```text
M = 2 x 3 x 5 = 30
```

A composed memory can then receive its own prime identifier and participate in another composition:

```text
DOG + PARK + DAY
        |
        v
   EXPERIENCE_A
        |
        v
prime assigned to EXPERIENCE_A
        |
        v
EXPERIENCE_A + CONTEXT + TIME
```

The implementation separates the encoded value of a memory from the prime assigned to a composite memory so higher-order structures can be recursively composed and explicitly traversed.

## Design Goals

The implementation is being developed around these engineering goals:

1. **Determinism**: identical registered inputs should produce predictable behavior.
2. **Reconstructability**: encoded structures should retain sufficient information for deterministic inspection and expansion.
3. **Unique symbol addressing**: registered symbols must not share prime identifiers.
4. **Recursive composability**: a composite memory may participate in higher-order composition.
5. **Graph integrity**: hierarchy operations must maintain explicit node and edge invariants.
6. **Cycle safety**: recursive expansion must detect recursive cycles rather than recurse indefinitely.
7. **Testability**: recursive and graph behavior must be verifiable through topology-driven tests.

## Repository Structure

```text
pairwise-memory/
├── .github/
│   ├── CODEOWNERS
│   ├── PULL_REQUEST_TEMPLATE.md
│   ├── ISSUE_TEMPLATE/
│   │   └── bug_report.yml
│   └── workflows/
│       └── ci.yml
├── docs/
│   └── COMMUNITY_HEALTH_CHECKLIST.md
├── examples/
├── src/
│   └── pairwise_memory/
│       └── prime_lattice/
│           ├── __init__.py
│           ├── allocator.py
│           ├── compression.py
│           ├── encoding.py
│           ├── engine.py
│           ├── factorization.py
│           ├── hierarchy.py
│           ├── lattice.py
│           ├── recall_graph.py
│           ├── recursive.py
│           ├── recursive_recall.py
│           ├── temporal.py
│           ├── temporal_allocator.py
│           ├── traversal.py
│           └── visualization.py
├── tests/
│   ├── factories/
│   │   └── recursive_graph_factory.py
│   ├── test_duplicate_edges.py
│   ├── test_factory_topologies.py
│   ├── test_recursive_edge_cases.py
│   └── test_topology_metrics.py
├── CODE_OF_CONDUCT.md
├── CONTRIBUTING.md
├── LICENSE
├── PATENTS.md
├── pyproject.toml
└── README.md
```

The exact tree may evolve as the engine is implemented further.

## Installation

### Requirements

- Python 3.11 or newer
- Git
- pip

Check Python:

```bash
python --version
```

### Clone

```bash
git clone https://github.com/jkhcw16-arch/pairwise-memory-site.git
cd pairwise-memory-site
```

Or with SSH:

```bash
git clone git@github.com:jkhcw16-arch/pairwise-memory-site.git
cd pairwise-memory-site
```

### Create a virtual environment

Linux or macOS:

```bash
python -m venv .venv
source .venv/bin/activate
```

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

### Install

```bash
python -m pip install --upgrade pip
pip install -e .
```

If development extras are defined in `pyproject.toml`:

```bash
pip install -e ".[dev]"
```

## Quick Start

```python
from pairwise_memory.prime_lattice.engine import PairwiseMemoryEngine

engine = PairwiseMemoryEngine()

engine.store(
    concepts=["DOG", "PARK"],
    timestamp="2026-01-15",
)

results = engine.query_concept("DOG")

for memory in results:
    print(memory)
```

### Recursive composition

```python
engine = PairwiseMemoryEngine()

episode = engine.compose(
    "DOG_AT_PARK",
    ["DOG", "PARK"],
)

story = engine.compose_memories(
    "WEEKEND_STORY",
    [episode.prime],
)

atomic_primes = engine.deep_expand("WEEKEND_STORY")
print(atomic_primes)
```

## Prime Lattice

The Prime Lattice subsystem is intended to provide deterministic symbolic addressing for concepts and compositions.

Core responsibilities include:

- Prime allocation
- Prime multiplication-based encoding
- Factorization-based inspection
- Memory registration
- Divisibility-based lookup
- Temporal factor inclusion
- Recursive composite registration

A memory value may be expressed conceptually as:

```text
M = product(p_i ^ e_i)
```

where the participating primes and multiplicities encode the composition selected by the engine.

Prime multiplication should not be interpreted as general-purpose data compression. Integer magnitude increases as factors accumulate, and production implementations must account for arithmetic, storage, indexing, and factorization costs.

## Recursive Memory Composition

Recursive composition promotes a previously defined memory structure into a reusable higher-order component.

```text
WEEKEND_STORY
|
+-- DOG_AT_PARK
|   +-- DOG
|   +-- PARK
|
+-- CONTEXT
```

The recursive subsystem maintains explicit composition metadata so expansion does not depend only on factoring an integer.

Expected recursive invariants include:

- Composite labels map to unique primes.
- Component relationships are explicitly recorded.
- Duplicate hierarchy edges are rejected.
- Cycles are detected during recursive traversal.
- Failed duplicate insertions do not mutate graph metrics.

## Temporal Memory

Temporal memory extends ordinary composition with a temporal factor or temporal identifier.

Conceptually:

```text
memory = concepts x temporal identifier
```

The temporal layer is intended to support deterministic filtering and chronological reconstruction while keeping temporal information distinct enough for explicit inspection.

## Graph Topologies and Robustness

The test suite uses reusable topology factories to exercise recursive behavior under normal and pathological graph structures.

Current test design includes:

- Self-loop
- Multiple independent self-loops
- Two-node cycle
- Multi-node cycle
- Diamond topology
- Star topology
- Deep recursive chain

Topology tests should verify both structural behavior and graph metrics such as node and edge counts.

## Duplicate-Edge Policy

A hierarchy edge may exist only once.

```text
A -> B     allowed
A -> B     duplicate insertion rejected
```

The same rule applies to self-loops:

```text
A -> A     first insertion allowed when the topology permits it
A -> A     duplicate insertion rejected
```

This protects graph metrics from accidental inflation and makes hierarchy mutation explicit.

## Testing

Run all tests:

```bash
pytest
```

Verbose output:

```bash
pytest -v
```

Coverage:

```bash
pytest --cov=src/pairwise_memory --cov-report=term-missing
```

Representative targeted suites:

```bash
pytest tests/test_recursive_edge_cases.py -v
pytest tests/test_factory_topologies.py -v
pytest tests/test_topology_metrics.py -v
pytest tests/test_duplicate_edges.py -v
```

## Development Quality Checks

When development dependencies are installed:

```bash
ruff check src tests
ruff format --check src tests
mypy src
pytest
```

See [`CONTRIBUTING.md`](CONTRIBUTING.md) for contribution requirements.

## Continuous Integration

The repository is designed to run automated tests through GitHub Actions, including the recursive topology and graph-integrity suite.

Before publishing the repository, replace `jkhcw16-arch` and `pairwise-memory-site` in the badge and clone URLs with the actual GitHub values.

## Contributing

Contributions should preserve the core invariants of the architecture and include appropriate tests.

Changes affecting recursive composition, hierarchy behavior, prime allocation, or traversal should include regression coverage for the affected invariants.

Please read:

- [`CONTRIBUTING.md`](CONTRIBUTING.md)
- [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md)
- [`PATENTS.md`](PATENTS.md)
- [`LICENSE`](LICENSE)

This is a proprietary project. Contribution acceptance does not create a patent or commercial license except through a separate written agreement.

## Reporting Bugs

Use the repository's GitHub bug-report issue form and include:

- Minimal reproduction steps
- Expected behavior
- Actual behavior
- Python version
- Operating system
- Relevant traceback
- Affected subsystem
- Topology size or recursion depth when relevant

Potential security vulnerabilities should be reported privately according to the repository's security policy rather than through a public issue.

## Commercial Licensing

The Pairwise Memory Architecture is proprietary technology. Commercial rights are not granted by access to this repository.

For OEM integrations, enterprise deployments, evaluations, research partnerships, or technology and patent licensing:

**Contact:** Jamie Kinney  
**Email:** Jkhcw9277@icloud.com

Potential commercial arrangements may include:

- OEM and embedded licensing
- Enterprise deployment
- Evaluation and proof-of-concept agreements
- Technology integration
- Research and development partnerships
- Custom implementation agreements
- Patent and intellectual-property licensing

Any commercial, production, redistribution, sublicensing, or patent rights require a separate written agreement.

## License and Intellectual Property

Copyright (c) 2026 Jamie Kinney. All Rights Reserved.

This repository is proprietary. No permission is granted to copy, modify, distribute, sublicense, sell, commercially exploit, or create derivative works from the software or associated materials except with prior written permission from the copyright holder or as otherwise permitted by applicable law.

Access to this repository does not grant any license or other right under any patent, patent application, trademark, trade secret, copyright, or other intellectual-property right.

See [`LICENSE`](LICENSE) for the complete repository license terms and [`PATENTS.md`](PATENTS.md) for the patent notice and patent-license limitations.

## Patent Notice

Aspects of the Pairwise Memory Architecture may be the subject of pending or future patent applications or other intellectual-property rights.

This README does **not** represent that any particular implementation is patented or patent pending. Refer to [`PATENTS.md`](PATENTS.md) for the repository's patent-status and no-patent-license notice.

## Disclaimer

This repository contains experimental software and research-oriented architectural material. It is provided under the terms stated in [`LICENSE`](LICENSE), without warranties to the maximum extent described there.

Mathematical descriptions in this repository describe the intended architecture and implementation model. Claims concerning performance, scalability, compression, novelty, patentability, or comparative superiority should be supported independently before being relied upon.

---

**Pairwise Memory Architecture**  
Jamie Kinney  
Commercial and licensing inquiries: Jkhcw9277@icloud.com
