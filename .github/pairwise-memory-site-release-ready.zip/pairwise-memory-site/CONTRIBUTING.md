# Contributing to Pairwise Memory Architecture

Thank you for contributing. This proprietary repository explores deterministic prime-lattice memory, recursive composition, temporal indexing, and exact symbolic recall.

## Development setup

```bash
git clone https://github.com/jkhcw16-arch/pairwise-memory-site.git
cd pairwise-memory-site
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e ".[dev]"
```

On Windows PowerShell, activate with:

```powershell
.venv\Scripts\Activate.ps1
```

## Engineering invariants

Contributions must preserve applicable invariants:

- deterministic behavior
- unique symbol-to-prime allocation
- lossless reconstruction metadata
- recursive composability
- duplicate-edge rejection
- cycle detection
- node-count and edge-count integrity

## Tests

Every behavioral change must include unit, edge-case, or regression tests as appropriate. Changes to recursive composition, hierarchy, traversal, or topology factories must test cycles, duplicates, and graph metrics.

```bash
ruff check src tests
ruff format --check src tests
mypy src
pytest
```

## Pull requests

Use a focused branch and the pull request template. Explain architectural or mathematical assumptions, identify breaking changes, and update documentation when behavior changes.

Recommended commit format:

```text
type(scope): description
```

Examples:

```text
feat(recursion): add multi-node cycle topology
fix(hierarchy): reject duplicate edges
test(factory): verify topology metrics
docs(readme): clarify installation
```

## Intellectual property

This is a proprietary project. Submission or acceptance of a contribution does not grant a patent, commercial, evaluation, redistribution, or sublicensing right except through a separate written agreement. Contributors must have authority to submit their work and must disclose relevant third-party licenses or restrictions.

See `LICENSE` and `PATENTS.md`.
