from pairwise_memory.core.memory import PairwiseMemory
