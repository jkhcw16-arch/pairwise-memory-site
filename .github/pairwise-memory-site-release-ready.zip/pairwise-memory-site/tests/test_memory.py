from pairwise_memory.core.memory import PairwiseMemory


def test_store():
 m=PairwiseMemory();m.store("a","b");assert m.recall("a","b")==1.0
