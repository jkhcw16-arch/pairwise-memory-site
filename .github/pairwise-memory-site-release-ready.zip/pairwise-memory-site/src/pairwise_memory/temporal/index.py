class TemporalIndex: pass
