class AssociativeGraph: pass
