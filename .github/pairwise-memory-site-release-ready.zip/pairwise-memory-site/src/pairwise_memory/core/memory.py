
class PairwiseMemory:
    def __init__(self):
        self.memory={}
    def store(self,left,right,weight=1.0):
        self.memory[(left,right)] = weight
    def recall(self,left,right):
        return self.memory.get((left,right))
